document.addEventListener("DOMContentLoaded", () => {
    // Mobile Navigation Toggle
    const menuToggle = document.getElementById("menu-toggle")
    const navLinks = document.getElementById("nav-links")
  
    if (menuToggle && navLinks) {
      menuToggle.addEventListener("click", () => {
        menuToggle.classList.toggle("active")
        navLinks.classList.toggle("active")
      })
    }
  
    // Close mobile menu when clicking outside
    document.addEventListener("click", (event) => {
      if (
        navLinks &&
        navLinks.classList.contains("active") &&
        !event.target.closest("#navbar") &&
        !event.target.closest("#menu-toggle")
      ) {
        navLinks.classList.remove("active")
        menuToggle.classList.remove("active")
      }
    })
  
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener("click", function (e) {
        if (this.getAttribute("href") !== "#") {
          e.preventDefault()
          const targetId = this.getAttribute("href")
          const targetElement = document.querySelector(targetId)
  
          if (targetElement) {
            // Close mobile menu if open
            if (navLinks && navLinks.classList.contains("active")) {
              navLinks.classList.remove("active")
              menuToggle.classList.remove("active")
            }
  
            // Scroll to target
            window.scrollTo({
              top: targetElement.offsetTop - 100,
              behavior: "smooth",
            })
          }
        }
      })
    })
  
    // Testimonial Slider
    const testimonialSlider = document.getElementById("testimonial-slider")
    const prevButton = document.getElementById("prev-testimonial")
    const nextButton = document.getElementById("next-testimonial")
  
    if (testimonialSlider && prevButton && nextButton) {
      const testimonials = testimonialSlider.querySelectorAll(".testimonial")
      let currentIndex = 0
  
      // Hide all testimonials except the first one
      testimonials.forEach((testimonial, index) => {
        if (index !== 0) {
          testimonial.style.display = "none"
        }
      })
  
      // Show next testimonial
      nextButton.addEventListener("click", () => {
        testimonials[currentIndex].style.display = "none"
        currentIndex = (currentIndex + 1) % testimonials.length
        testimonials[currentIndex].style.display = "block"
      })
  
      // Show previous testimonial
      prevButton.addEventListener("click", () => {
        testimonials[currentIndex].style.display = "none"
        currentIndex = (currentIndex - 1 + testimonials.length) % testimonials.length
        testimonials[currentIndex].style.display = "block"
      })
  
      // Auto-rotate testimonials
      setInterval(() => {
        if (document.visibilityState === "visible") {
          testimonials[currentIndex].style.display = "none"
          currentIndex = (currentIndex + 1) % testimonials.length
          testimonials[currentIndex].style.display = "block"
        }
      }, 8000)
    }
  
    // FAQ Accordion
    const faqItems = document.querySelectorAll(".faq-item")
  
    if (faqItems.length > 0) {
      faqItems.forEach((item) => {
        const question = item.querySelector(".faq-question")
  
        question.addEventListener("click", () => {
          // Close other open FAQs
          faqItems.forEach((otherItem) => {
            if (otherItem !== item && otherItem.classList.contains("active")) {
              otherItem.classList.remove("active")
            }
          })
  
          // Toggle current FAQ
          item.classList.toggle("active")
        })
      })
    }
  
    // FAQ Search Functionality
    const faqSearch = document.getElementById("faq-search")
    const faqList = document.getElementById("faq-list")
    const faqNotFound = document.getElementById("faq-not-found")
  
    if (faqSearch && faqList) {
      faqSearch.addEventListener("input", function () {
        const searchTerm = this.value.toLowerCase()
        const items = faqList.querySelectorAll(".faq-item")
        let hasResults = false
  
        items.forEach((item) => {
          const question = item.querySelector(".faq-question h3").textContent.toLowerCase()
          const answer = item.querySelector(".faq-answer").textContent.toLowerCase()
  
          if (question.includes(searchTerm) || answer.includes(searchTerm)) {
            item.style.display = "block"
            hasResults = true
          } else {
            item.style.display = "none"
          }
        })
  
        // Show/hide "no results" message
        if (faqNotFound) {
          faqNotFound.style.display = hasResults ? "none" : "block"
        }
      })
    }
  
    // FAQ Category Filtering
    const categoryTabs = document.querySelectorAll(".category-tab")
  
    if (categoryTabs.length > 0 && faqList) {
      categoryTabs.forEach((tab) => {
        tab.addEventListener("click", function () {
          // Remove active class from all tabs
          categoryTabs.forEach((otherTab) => {
            otherTab.classList.remove("active")
          })
  
          // Add active class to clicked tab
          this.classList.add("active")
  
          const category = this.getAttribute("data-category")
          const items = faqList.querySelectorAll(".faq-item")
  
          items.forEach((item) => {
            if (category === "all" || item.getAttribute("data-category") === category) {
              item.style.display = "block"
            } else {
              item.style.display = "none"
            }
          })
  
          // Hide "no results" message when filtering by category
          if (faqNotFound) {
            faqNotFound.style.display = "none"
          }
        })
      })
    }
  
    // Chat Widget
    const chatToggle = document.getElementById("chat-toggle")
    const chatBox = document.getElementById("chat-box")
    const closeChat = document.getElementById("close-chat")
    const chatForm = document.getElementById("chat-form")
    const chatInput = document.getElementById("chat-input")
    const chatMessages = document.getElementById("chat-messages")
    const openChatFromCard = document.getElementById("open-chat-from-card")
  
    if (chatToggle && chatBox && closeChat) {
      // Open chat
      chatToggle.addEventListener("click", () => {
        chatBox.classList.add("active")
        chatBox.style.display = "block"
        chatToggle.style.display = "none"
  
        // Focus on input field
        if (chatInput) {
          chatInput.focus()
        }
      })
  
      // Open chat from contact card if it exists
      if (openChatFromCard) {
        openChatFromCard.addEventListener("click", () => {
          chatBox.classList.add("active")
          chatBox.style.display = "block"
          chatToggle.style.display = "none"
  
          // Focus on input field
          if (chatInput) {
            chatInput.focus()
          }
        })
      }
  
      // Close chat
      closeChat.addEventListener("click", () => {
        chatBox.classList.remove("active")
        chatBox.style.display = "none"
        chatToggle.style.display = "block"
      })
  
      // Handle chat form submission
      if (chatForm && chatInput && chatMessages) {
        chatForm.addEventListener("submit", (e) => {
          e.preventDefault()
  
          const message = chatInput.value.trim()
  
          if (message !== "") {
            // Add user message
            const userMessage = document.createElement("div")
            userMessage.className = "message sent"
            userMessage.innerHTML = `<p>${message}</p>`
            chatMessages.appendChild(userMessage)
  
            // Clear input
            chatInput.value = ""
  
            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight
  
            // Simulate response (in a real implementation, this would be handled by a backend)
            setTimeout(() => {
              const botMessage = document.createElement("div")
              botMessage.className = "message received"
              botMessage.innerHTML = `<p>Thank you for your message. One of our advisors will respond to you shortly. In the meantime, you might find helpful information in our <a href="faq.html">FAQ section</a>.</p>`
              chatMessages.appendChild(botMessage)
  
              // Scroll to bottom
              chatMessages.scrollTop = chatMessages.scrollHeight
            }, 1000)
          }
        })
      }
    }
  
    // Form Submissions
    const contactForm = document.getElementById("contact-form")
    const bookingForm = document.getElementById("booking-form")
    const questionForm = document.getElementById("question-form")
  
    // Handle contact form submission
    if (contactForm) {
      contactForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // In a real implementation, this would send data to a server
        alert("Thank you for your message. We will get back to you soon!")
        contactForm.reset()
      })
    }
  
    // Handle booking form submission
    if (bookingForm) {
      bookingForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // In a real implementation, this would send data to a server
        alert("Thank you for booking a consultation. We will confirm your appointment shortly!")
        bookingForm.reset()
      })
    }
  
    // Handle question form submission
    if (questionForm) {
      questionForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // In a real implementation, this would send data to a server
        alert("Thank you for your question. We will email you with an answer soon!")
        questionForm.reset()
      })
    }
  
    // Highlight active navigation link based on current page
    const currentPage = window.location.pathname.split("/").pop()
    const navLinksList = document.querySelectorAll("#nav-links a")
  
    navLinksList.forEach((link) => {
      const linkPage = link.getAttribute("href")
      if (linkPage === currentPage) {
        link.classList.add("active")
      }
    })
  
    // Add active class to pathway/resource navigation items when scrolling
    const sections = document.querySelectorAll(".pathway, .resource-section")
    const navItems = document.querySelectorAll(".pathway-nav-item, .resource-nav-item")
  
    if (sections.length > 0 && navItems.length > 0) {
      window.addEventListener("scroll", () => {
        let current = ""
  
        sections.forEach((section) => {
          const sectionTop = section.offsetTop - 150
          const sectionHeight = section.clientHeight
  
          if (pageYOffset >= sectionTop && pageYOffset < sectionTop + sectionHeight) {
            current = section.getAttribute("id")
          }
        })
  
        navItems.forEach((item) => {
          item.classList.remove("active")
          const href = item.getAttribute("href").substring(1)
  
          if (href === current) {
            item.classList.add("active")
          }
        })
      })
    }
  })
  
  